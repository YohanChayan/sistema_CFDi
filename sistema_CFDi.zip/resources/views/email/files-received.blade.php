<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Archivos del proveedor {{ $name_provider }}</title>
</head>
<body>
  <h1>Se adjuntan los archivos correspondientes (xml, pdf y anexo, este último en caso de ser necesario)</h1>
</body>
</html>