<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Archivos Recibidos</title>
</head>
<body>
  {{-- <object data="{{ asset('archivos/xml/1657760050.xml') }}" type="application/xml"></object>
  <object data="{{ asset('archivos/pdf/1657760050.pdf') }}" type="application/pdf" style="width: 400px; height: 550px;"></object> --}}
  {{-- @if ($other_name != '')
    <object data="{{ asset($other_name) }}" ></object>
  @endif --}}
</body>
</html>